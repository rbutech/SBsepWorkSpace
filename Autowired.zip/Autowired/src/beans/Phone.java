package beans;

import org.springframework.beans.factory.annotation.Value;

public class Phone {
	@Value("${phone_name}")
	private String phoneName;

	@Override
	public String toString() {
		return "Phone [phoneName=" + phoneName + "]";
	}
	

}
