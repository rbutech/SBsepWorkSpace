package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.ApplicationProperties;
import beans.Phone;
import beans.Sim;

public class IOCTest {
public static void main(String[] args) {
	ApplicationContext ap=new ClassPathXmlApplicationContext("resources/spring.xml");
	Phone phone=ap.getBean(Phone.class);
	Sim sim=ap.getBean(Sim.class);
	System.out.println(phone);
	System.out.println(sim);
	ApplicationProperties p=ap.getBean(ApplicationProperties.class);
	System.out.println(p);
}
}
