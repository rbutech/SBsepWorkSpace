package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.rbu.ems.dao.EmployeeDaoDI;

public class IOCContainer {
	public static void main(String[] args) {
		// START IOC
		ApplicationContext ap = new ClassPathXmlApplicationContext("resources/spring.xml");

//EmployeeDao dao=(EmployeeDao)ap.getBean("dao");
//		EmployeeDao dao = ap.getBean(EmployeeDao.class);
//		dao.createEmploye(1, "rajesh", "rajesh@gmail.com", "HYD");

		EmployeeDaoDI dao_di = ap.getBean(EmployeeDaoDI.class);
		dao_di.createEmploye(2, "naveen", "naveen@rbutech.in", "HYD");
	}
}
