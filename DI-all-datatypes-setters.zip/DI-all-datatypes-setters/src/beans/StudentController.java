package beans;

import java.util.List;
import java.util.Map;
import java.util.Set;

import lombok.Setter;
import lombok.ToString;

//Frontend->controller(service),Service($APIurl,DAO)->Dao(db config)-DataBase
@Setter
@ToString
public class StudentController {
	// primitives
	private int roleno;
	private String name; 
	private boolean active;
	// array type
	private String[] courses;
	IStudentService service;
	List<String> fruits;
	Set<String> cricketers;
	Map<String, String> statecap;
	//www.durgasoft.com/register
	public void useIt() {
		System.out.println(roleno);
		System.out.println(name);
		System.out.println(active);		
		for(String s:courses) {
			System.out.println(s);
		}
		service.serviceMethod();
	}

}
