package beans;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

import lombok.Setter;
import lombok.ToString;

//Frontend->controller(service),Service($APIurl,DAO)->Dao(db config)-DataBase
@Setter
@ToString
public class StudentController2 {
	// primitives
	private int roleno;
	private String name; 
	private boolean active;
	// array type
	private String[] courses;
	IStudentService service;
	LinkedList<String> fruits;
	TreeSet<String> cricketers;
	TreeMap<String, String> statecap;
	
	public void useIt() {
		System.out.println(roleno);
		System.out.println(name);
		System.out.println(active);		
		for(String s:courses) {
			System.out.println(s);
		}
		service.serviceMethod();
	}

}
