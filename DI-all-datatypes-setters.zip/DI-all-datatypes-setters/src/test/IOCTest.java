package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.StudentController;
import beans.StudentController2;

public class IOCTest {
public static void main(String[] args) {
	
	ApplicationContext ap=new ClassPathXmlApplicationContext("resources/spring.xml");
	//create object first
	//call setters next
	StudentController std=ap.getBean(StudentController.class);
	std.useIt();
	System.out.println(std);
	
	StudentController2 std2=ap.getBean(StudentController2.class);

	System.out.println(std2);
	
	
}
}
