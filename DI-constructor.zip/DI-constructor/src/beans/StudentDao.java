package beans;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

import lombok.AllArgsConstructor;
@AllArgsConstructor
public class StudentDao {
	String driver;
	String url;
	String username;
	String password;

//	public StudentDao(String driver, String url, String username, String password) {
//		super();
//		this.driver = driver;
//		this.url = url;
//		this.username = username;
//		this.password = password;
//	}

	public void createStudent(int id, String name, String email, String address) {
		try {
			Class.forName(driver);
			Connection con = DriverManager.getConnection(url, username, password);
			Statement statement = con.createStatement();
			statement.executeUpdate(
					"insert into student values(" + id + ",'" + name + "','" + email + "','" + address + "')");
			statement.close();
			con.close();
			System.out.println("insert success");
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
