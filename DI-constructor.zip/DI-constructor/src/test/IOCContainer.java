package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.StudentDao;

public class IOCContainer {
	public static void main(String[] args) {
		// START IOC
		ApplicationContext ap = new ClassPathXmlApplicationContext("resources/spring.xml");
		
		StudentDao dao=	ap.getBean(StudentDao.class);
		dao.createStudent(1, "dixit", "dixit@rbutech.in", "HYD");
		dao.createStudent(2, "abhi", "abhi@rbutech.in", "HYD");
		dao.createStudent(3, "tushar", "tushar@rbutech.in", "HYD");
		dao.createStudent(4, "priyanka", "priyanka@rbutech.in", "HYD");
	}
}
