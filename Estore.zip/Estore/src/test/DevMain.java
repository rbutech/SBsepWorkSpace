package test;

import com.rbu.estore.web.OrderController;

public class DevMain {
	public static void main(String[] args) {
		// naveen want to order milk
		OrderController or1 = new OrderController();
		// dixit pen
		OrderController or2 = new OrderController();
		// akash book
		OrderController or3 = new OrderController();

		for (int i = 0; i < 5000000; i++) {
			OrderController or = new OrderController();
		}

	}
}
