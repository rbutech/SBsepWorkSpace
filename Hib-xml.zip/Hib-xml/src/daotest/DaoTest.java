package daotest;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.rbu.ems.model.Student;

public class DaoTest {
	public static void main(String[] args) {
		// start Hib Containers
		Configuration cfg = new Configuration();
		cfg.configure("resources/oracle.cfg.xml");
		// build sf
		SessionFactory sf = cfg.buildSessionFactory();
			//HIB-ORM   EJB-ENT-->weblogic
		 
		// ready for CRUD

		// save : put your data into bean coming from end user
		Student student = new Student();
		student.setId(2);
		student.setName("naveen");
		student.setEmail("naveen@gmail.com");
		student.setAddress("PUNE");
	Session session = sf.openSession();// will provide one session
	session.beginTransaction().begin();
	session.save(student); // query generated and data inserted into DB
//session.update(student);
		
		//Student std=(Student) session.load(Student.class, 2);
		//System.out.println(std.getName()+":"+student.getEmail()+":"+std.getAddress());
		session.beginTransaction().commit();
		session.close();
		System.out.println("success");

	}
}
