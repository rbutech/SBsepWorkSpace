package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class IOCContainer {
public static void main(String[] args) {
	//now servers is simple java class forget about special software
	ApplicationContext ap=new ClassPathXmlApplicationContext("resources/spring.xml");
	
}
}
