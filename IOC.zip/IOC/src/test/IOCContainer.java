package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class IOCContainer {
public static void main(String[] args) {
	//Car c=new Car();//core java not able to create it
	// starting IOC container
	ApplicationContext ap=new ClassPathXmlApplicationContext("resources/spring.xml");
	//Car c=new Car();
	
//	try {
//		Class c=Class.forName("beans.Car");
//		Constructor<Car> con[]=c.getDeclaredConstructors();
//		con[0].setAccessible(true);
//		try {
//			con[0].newInstance();
//		} catch (InstantiationException | IllegalAccessException | IllegalArgumentException
//				| InvocationTargetException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//	} catch (ClassNotFoundException e) {
//		// TODO Auto-generated catch block
//		e.printStackTrace();
//	}
//	
	
	
}
}
