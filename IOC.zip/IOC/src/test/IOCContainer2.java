package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import beans.Bank;
import beans.Car;
import beans.Company;
import beans.Employee;
import beans.Test;
import beans.User;

public class IOCContainer2 {
	public static void main(String[] args) {
		ApplicationContext ap = new ClassPathXmlApplicationContext("resources/spring.xml");
		// all objects with singleton created
		// get object which are created with IOC using their id's
		Bank b     = ap.getBean(Bank.class);
		Car c      = ap.getBean(Car.class);
		Employee e = ap.getBean(Employee.class);
		Company co = ap.getBean(Company.class);
		Test t     = ap.getBean(Test.class);
		User u     = ap.getBean(User.class);
		// calling methods
		System.out.println("-----------------After Object---------------------");
		b.myaccout();
		c.mycar();
		e.department();
		co.noofEmp();
		t.testMethod();
		u.hello();
		b.myaccout();
		c.mycar();
		e.department();
		co.noofEmp();
		t.testMethod();
		u.hello();
		b.myaccout();
		c.mycar();
		e.department();
		co.noofEmp();
		t.testMethod();
		u.hello();
		b.myaccout();
		c.mycar();
		e.department();
		co.noofEmp();
		t.testMethod();
		u.hello();
		b.myaccout();
		c.mycar();
		e.department();
		co.noofEmp();
		t.testMethod();
		u.hello();
		b.myaccout();
		c.mycar();
		e.department();
		co.noofEmp();
		t.testMethod();
		u.hello();
		b.myaccout();
		c.mycar();
		e.department();
		co.noofEmp();
		t.testMethod();
		u.hello();

	}
}
