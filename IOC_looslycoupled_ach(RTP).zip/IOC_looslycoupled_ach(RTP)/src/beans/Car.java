package beans;

public class Car {
	ITyre iTyre;
	//DI
	public void setiTyre(ITyre iTyre) {
		this.iTyre = iTyre;
	}

	public void drive() {
		System.out.println("TYRE NAME:" + iTyre.name());
		System.out.println("TYRE SIZE:" + iTyre.size());
		System.out.println("TYRE PATTERN:" + iTyre.pattern());

	}
}
