package beans;
//inheritance
public class YokohamaTyre implements ITyre {
	
	@Override
	public String name() {
		
		return "YokohamaTyre";
	}

	@Override
	public String pattern() {
		// TODO Auto-generated method stub
		return "4 layer";
	}

	@Override
	public int size() {
		// TODO Auto-generated method stub
		return 17;
	}

}
