package com.rbu.ems.config;

import java.beans.PropertyVetoException;

import javax.sql.DataSource;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

import com.mchange.v2.c3p0.ComboPooledDataSource;

@Configuration
public class AppConfig {

	public AppConfig() {
		System.out.println("AppConfig object created..");
	}

//	@Bean(name = "bds")
//	public DataSource createConnectionPool() {
//		System.out.println("BDS:createConnectionPool....");
//		BasicDataSource bds = new BasicDataSource();// at a time it can hold N number of connections
//		bds.setDriverClassName("oracle.jdbc.OracleDriver");
//		bds.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
//		bds.setUsername("system");
//		bds.setPassword("admin");
//		bds.setMaxActive(1);
//		bds.setMaxWait(2000);
//		return bds;
//	}
	//IOC will create object for CPD during loading
	@Bean(name = "c3p0")
	public DataSource createConnectionPoolwithC3P0() throws PropertyVetoException {
		System.out.println("C3P0:createConnectionPool....");
		ComboPooledDataSource cp = new ComboPooledDataSource();// at a time it can hold N number of connections
		cp.setDriverClass("oracle.jdbc.OracleDriver");
		cp.setJdbcUrl("jdbc:oracle:thin:@localhost:1521:xe");
		cp.setUser("system");
		cp.setPassword("admin");
		cp.setMaxPoolSize(10);
		cp.setMaxIdleTime(2000);
		return cp;
	}

	@Bean
	public JdbcTemplate createJt() throws PropertyVetoException {
		JdbcTemplate jdbcTemplate = new JdbcTemplate();
		jdbcTemplate.setDataSource(createConnectionPoolwithC3P0());//Manual DI IOC created object will be injected
		return jdbcTemplate;
	}
	
	@Bean
	public NamedParameterJdbcTemplate createNpJt() throws PropertyVetoException {
		NamedParameterJdbcTemplate npJdbcTemplate = new NamedParameterJdbcTemplate(createConnectionPoolwithC3P0());//Manual DI IOC created object will be injected
		return npJdbcTemplate;
	}
	
	

//	@Bean(name = "hikari")
//	public DataSource createConnectionPoolwithHikari() throws PropertyVetoException {
//		System.out.println("Hikari:createConnectionPool....");
//		HikariConfig config = new HikariConfig();
//		config.setDriverClassName("oracle.jdbc.driver.OracleDriver");
//		config.setJdbcUrl("jdbc:oracle:thin:@localhost:1521:xe");
//		config.setUsername("system");
//		config.setPassword("admin");
//		config.setMaximumPoolSize(10);
//		return new HikariDataSource(config);
//	}

}
