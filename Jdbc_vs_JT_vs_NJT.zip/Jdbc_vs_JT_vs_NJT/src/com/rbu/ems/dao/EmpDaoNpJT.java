package com.rbu.ems.dao;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class EmpDaoNpJT {

	@Autowired
	NamedParameterJdbcTemplate npJdbcTemplate;

	public EmpDaoNpJT() {
		System.out.println("EmpDao object created");
	}

	// 100Dao 5crud(1-lines) methods 2500 vs 500
	public String save(int id, String name, String email, String address) {
		//PreparedStatement style:
		Map map=new HashMap<String, Object>();
		map.put("id", id);
		map.put("name", name);
		map.put("email", email);
		map.put("address", address);
		npJdbcTemplate.update("insert into RBU_EMP values(:id,:name,:email,:address)",map);
		return "SUCCESS";
	}

	public String update(int id, String name, String email, String address) {
//		jdbcTemplate.update("update RBU_EMP set name='" + name + "',email='" + email + "',address='" + address
//				+ "' where id=" + id + "");
		Map map=new HashMap<String, Object>();
		map.put("id", id);
		map.put("name", name);
		map.put("email", email);
		map.put("address", address);
		npJdbcTemplate.update("update RBU_EMP set name=:name,email=:email,address=:address where id=:id",map);
		return "SUCCESS";
	}

	public String delete(int id) {
		//jdbcTemplate.update("delete RBU_EMP where id=" + id);
		Map map=new HashMap<String, Object>();
		map.put("id", id);
		npJdbcTemplate.update("delete RBU_EMP where id=:id",map);
		return "SUCCESS";
	}

	public Employee findEmp(int id) {
		//Employee emp = jdbcTemplate.queryForObject("select * from RBU_EMP where id=" + id, new RS_toEMP_RMP());
		Map map=new HashMap<String, Object>();
		map.put("id", id);
		Employee emp=npJdbcTemplate.queryForObject("select * from RBU_EMP where id=:id",map,new RS_toEMP_RMP());
		return emp;
	}

	public List<Employee> findAllEmp() {
		List<Map<String, Object>> list = npJdbcTemplate.queryForList("select * from RBU_EMP",new HashMap());
		List<Employee> empList = new ArrayList<Employee>();
		for (Map map : list) {
			Employee emp = new Employee();
			BigDecimal id = (BigDecimal) map.get("ID");
			String name = (String) map.get("NAME");
			String email = (String) map.get("EMAIL");
			String address = (String) map.get("ADDRESS");
			emp.setId(id.intValue());
			emp.setName(name);
			emp.setEmail(email);
			emp.setAddress(address);
			empList.add(emp);
		}
		return empList;

	}

}
