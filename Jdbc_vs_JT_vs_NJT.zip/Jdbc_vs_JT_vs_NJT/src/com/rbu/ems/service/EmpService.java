package com.rbu.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rbu.ems.dao.EmpDaoJt;
import com.rbu.ems.dao.Employee;

@Service
public class EmpService {
	@Autowired
	EmpDaoJt dao;

	public EmpService() {
		System.out.println("EmpService object created");
	}

	public String create(int id, String name, String email, String address) {
		System.out.println("vai datasource");
		String msg = dao.save(id, name, email, address);
		return msg;
	}

	public String update(int id, String name, String email, String address) {
		System.out.println("vai datasource");
		String msg = dao.update(id, name, email, address);
		return msg;
	}

	public String delete(int id) {
		System.out.println("vai datasource");
		String msg = dao.delete(id);
		return msg;
	}

	public Employee selectEmpById(int id) {
		System.out.println("vai datasource");
		return dao.findEmp(id);
	}

	public List<Employee> findAllEmp() {
		return dao.findAllEmp();
	}

}
