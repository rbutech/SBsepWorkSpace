package com.rbu.ems.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.rbu.ems.dao.Employee;
import com.rbu.ems.service.EmpService;

@Controller
public class EmpController {
	@Autowired
	EmpService empService;

	public EmpController() {
		System.out.println("EmpController object created");
	}
	//1000 students are calling this method 10000 all success
	public String post(int id, String name, String email, String address) {
		String msg = empService.create(id, name, email, address);
		return msg;
	}
	public String put(int id, String name, String email, String address) {
		String msg = empService.update(id, name, email, address);
		return msg;
	}
	public String delete(int id) {
		String msg = empService.delete(id);
		return msg;
	}
	public Employee getbyId(int id) {
		return empService.selectEmpById(id);
	}
	public List<Employee> getAll() {
		return empService.findAllEmp();
	}
	
}
