package beans;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@AllArgsConstructor //param cnstructor
@NoArgsConstructor //def constructor
@Data //setter getter toString
public class Student {
	private String studentName;
	private String studentEmail;
	private String studentAddress;
    //controller methods || controller
	//business methods   || business
	//crud methods        || dao
}
