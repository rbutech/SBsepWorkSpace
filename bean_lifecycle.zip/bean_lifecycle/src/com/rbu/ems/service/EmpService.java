package com.rbu.ems.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rbu.ems.dao.EmpDao;

@Service
public class EmpService {
	@Autowired
	EmpDao dao;
	
	public EmpService() {
	System.out.println("EmpService object created");
	}
	
	

	public String create(int id, String name, String email, String address) {
		String msg = dao.save(id, name, email, address);
		return msg;
	}

}
