package beans;

public class B {
public void businessLogic(String name,String email) {
	System.out.println("B  businessLogic method");
	C c=new C();
	c.save(name, email);
}
}
