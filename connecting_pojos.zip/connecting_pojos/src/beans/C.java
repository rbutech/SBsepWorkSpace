package beans;

public class C {

	public void save(String name,String email) {
		System.out.println("C class save method");
		System.out.println(name);
		System.out.println(email);
	}
}
