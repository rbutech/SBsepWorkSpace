package beans;

import java.util.Date;

public class Attendence {
private int empid;
private String empname;
private Date intime;
private Date outtime;
}
