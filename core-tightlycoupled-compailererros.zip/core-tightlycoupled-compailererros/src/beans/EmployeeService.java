package beans;

public class EmployeeService {

	public void showPayDetails() {
		Payment p=new Payment();
	}
	public void showAttendence() {
		Attendence a=new Attendence();
	}
}
