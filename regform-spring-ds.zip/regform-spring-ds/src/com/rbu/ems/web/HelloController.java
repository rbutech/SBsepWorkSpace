package com.rbu.ems.web;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

public class HelloController implements Controller{
@Override
public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response) throws Exception {
	String name=request.getParameter("name");
	System.out.println(name);
	Map<String, Object> map=new HashMap<String, Object>();
	map.put("msg", "Hello..... Mr/MS:"+name);
	//request.setAttribute("msg", "Hello..... Mr/MS:"+name);
	
	return new ModelAndView("hello",map);//page name+ map(reqscope) object
//VR : DS: response.sendRedirect("./WEB-INF/successpages/hello.jsp");

}
}
