package com.rbu.ems.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate3.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.rbu.ems.dto.EmployeeDto;
import com.rbu.ems.model.Employee;

@Repository
public class EmployeDaoHt {
	@Autowired
	HibernateTemplate hibernateTemplate;

	public EmployeeDto save(EmployeeDto dto) {
		Employee employee = new Employee();
		BeanUtils.copyProperties(dto, employee);
		long id = (Long) hibernateTemplate.save(employee);
		dto.setId(id);
		return dto;
	}

	public EmployeeDto update(EmployeeDto dto) throws EmplNotFoundException {
		Employee emp = (Employee) hibernateTemplate.get(Employee.class, dto.getId());
		BeanUtils.copyProperties(dto, emp);
		if (null != emp) {
			hibernateTemplate.update(emp);
		} else {
			throw new EmplNotFoundException("Employee record not available with given  ID");
		}
		return dto;
	}

	public void delete(EmployeeDto dto) throws EmplNotFoundException {
		Employee emp = (Employee) hibernateTemplate.get(Employee.class, dto.getId());
		if (null != emp) {
			hibernateTemplate.delete(emp);
		} else {
			throw new EmplNotFoundException("Employee record not available with given  ID");
		}
	}

	public EmployeeDto findById(EmployeeDto dto) throws EmplNotFoundException {
		Employee emp = (Employee) hibernateTemplate.get(Employee.class, dto.getId());
		if (null != emp) {
			BeanUtils.copyProperties(emp, dto);
			return dto;
		} else {
			throw new EmplNotFoundException("Employee record not available with given  ID");
		}
	}

	public List<EmployeeDto> findAll() throws EmplNotFoundException {

		List<Employee> employeeList = hibernateTemplate.find("from Employee");// select * from employee007
		List<EmployeeDto> dtoList = new ArrayList<EmployeeDto>();
		if (!employeeList.isEmpty()) {
			for (Employee emp : employeeList) {
				EmployeeDto dto = new EmployeeDto();
				BeanUtils.copyProperties(emp, dto);
				dtoList.add(dto);
			}
			return dtoList;
		} else {
			throw new EmplNotFoundException("No Employee record available");
		}
	}
}
