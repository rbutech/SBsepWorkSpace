package com.rbu.ems.dao;

import org.springframework.stereotype.Repository;

@Repository
public class MyDao {
public MyDao() {
System.out.println("MyDao object created..");
}
}
