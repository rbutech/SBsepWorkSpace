package com.rbu.ems.service;

import org.springframework.stereotype.Service;

@Service
public class MyService {
	
	public MyService() {
		System.out.println("MyService obect created");
	}

}
