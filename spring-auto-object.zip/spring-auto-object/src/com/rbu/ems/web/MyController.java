package com.rbu.ems.web;

import org.springframework.stereotype.Controller;

@Controller
public class MyController {
	public MyController() {
		System.out.println("MyController object created");
	}

}
