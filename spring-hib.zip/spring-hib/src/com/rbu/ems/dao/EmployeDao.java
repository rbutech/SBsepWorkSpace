package com.rbu.ems.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.rbu.ems.dto.EmployeeDto;
import com.rbu.ems.model.Employee;

@Repository
public class EmployeDao {
	@Autowired
	SessionFactory factory;

	public EmployeeDto save(EmployeeDto dto) {
		Session session = factory.openSession();
		session.beginTransaction().begin();
		Employee employee = new Employee();
		BeanUtils.copyProperties(dto, employee);
		long id = (Long) session.save(employee);
		session.beginTransaction().commit();
		session.close();
		dto.setId(id);
		return dto;
	}

	public EmployeeDto update(EmployeeDto dto) throws EmplNotFoundException {
		Session session = factory.openSession();
		Employee emp = (Employee) session.get(Employee.class, dto.getId());
		BeanUtils.copyProperties(dto, emp);
		
		if (null != emp) {
			session.beginTransaction().begin();
			session.update(emp);
			session.beginTransaction().commit();
			session.close();
		} else {
			session.close();
			throw new EmplNotFoundException("Employee record not available with given  ID");
		}

		return dto;
	}

	public void delete(EmployeeDto dto) throws EmplNotFoundException {
		Session session = factory.openSession();
		Employee emp = (Employee) session.get(Employee.class, dto.getId());
		if (null != emp) {
			session.beginTransaction().begin();
			session.delete(emp);
			session.beginTransaction().commit();
			session.close();
		} else {
			session.close();
			throw new EmplNotFoundException("Employee record not available with given  ID");
		}
	}

	public EmployeeDto findById(EmployeeDto dto) throws EmplNotFoundException {
		Session session = factory.openSession();
		Employee emp = (Employee) session.get(Employee.class, dto.getId());
		if (null != emp) {
			BeanUtils.copyProperties(emp, dto);
			session.close();
			return dto;
		} else {
			session.close();
			throw new EmplNotFoundException("Employee record not available with given  ID");
		}
	}

	public List<EmployeeDto> findAll() throws EmplNotFoundException {
		Session session = factory.openSession();
		Query query = session.createQuery("from Employee");// select * from employee007
		List<Employee> employeeList = query.list();
		List<EmployeeDto> dtoList = new ArrayList<EmployeeDto>();
		if (!employeeList.isEmpty()) {
			for (Employee emp : employeeList) {
				EmployeeDto dto = new EmployeeDto();
				BeanUtils.copyProperties(emp, dto);
				dtoList.add(dto);
			}
			session.close();
			return dtoList;
		} else {
			session.close();
			throw new EmplNotFoundException("No Employee record available");
		}
	}
}
