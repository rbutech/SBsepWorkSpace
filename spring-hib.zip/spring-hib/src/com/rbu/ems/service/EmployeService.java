package com.rbu.ems.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rbu.ems.dao.EmplNotFoundException;
import com.rbu.ems.dao.EmployeDaoHt;
import com.rbu.ems.dto.EmployeeDto;

@Service
public class EmployeService {
	@Autowired
	EmployeDaoHt dao;
	//EmployeDao dao;

	public EmployeeDto createEmploye(EmployeeDto dto) {
		return dao.save(dto);
	}

	public EmployeeDto updateEmploye(EmployeeDto dto) throws EmplNotFoundException {
		return dao.update(dto);
	}

	public void deleteEmploye(EmployeeDto dto) throws EmplNotFoundException {
		dao.delete(dto);
	}

	public EmployeeDto findEmploye(EmployeeDto dto) throws EmplNotFoundException {
		return dao.findById(dto);
	}

	public List<EmployeeDto> findAll() throws EmplNotFoundException {
		return dao.findAll();
	}

}
