package com.rbu.ems.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.rbu.ems.dao.EmplNotFoundException;
import com.rbu.ems.dto.EmployeeDto;
import com.rbu.ems.service.EmployeService;

@Controller
public class EmployeController {
	@Autowired
	EmployeService employeService;

	public EmployeeDto post(EmployeeDto dto) {
		return employeService.createEmploye(dto);
	}

	public EmployeeDto put(EmployeeDto dto) throws EmplNotFoundException {
		return employeService.updateEmploye(dto);
	}

	public void delete(EmployeeDto dto) throws EmplNotFoundException {
		employeService.deleteEmploye(dto);
	}

	public EmployeeDto getById(EmployeeDto dto) throws EmplNotFoundException {
		return employeService.findEmploye(dto);
	}

	public List<EmployeeDto> getAll() throws EmplNotFoundException {
		return employeService.findAll();
	}
}
