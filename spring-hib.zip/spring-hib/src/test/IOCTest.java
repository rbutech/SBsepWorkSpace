package test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.rbu.ems.dao.EmplNotFoundException;
import com.rbu.ems.dto.EmployeeDto;
import com.rbu.ems.web.EmployeController;

public class IOCTest {
public static void main(String[] args) throws EmplNotFoundException {
	ApplicationContext ap=new ClassPathXmlApplicationContext("resources/spring.xml");
	
	EmployeController controller=ap.getBean(EmployeController.class);
	EmployeeDto dto=
			EmployeeDto.builder()
			//.name("dixit")
			//.email("dixit@gmail.com")
			//.address("MH")
			//.phone("568944546")
			.id(8l)
			.build();
	
	//dto=controller.post(dto);
	//dto=controller.put(dto);
	//dto=controller.getById(dto);
	List<EmployeeDto> dtoList=controller.getAll();
	//System.out.println(dto);
	dtoList.forEach(d->System.out.println(d));
	//controller.delete(dto);
	
}
}
