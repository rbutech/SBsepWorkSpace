package com.rbu.ems.config;

import javax.sql.DataSource;

import org.apache.tomcat.dbcp.dbcp.BasicDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestTemplate;

import com.google.gson.Gson;

@Configuration
//@SpringBootApplication
public class AppConfig {
	
	public AppConfig() {
		System.out.println("AppConfig object created..");
	}

	@Bean
	public DataSource createConnectionPool() {
		System.out.println("createConnectionPool....");
		BasicDataSource bds = new BasicDataSource();// at a time it can hold N number of connections
		bds.setDriverClassName("oracle.jdbc.OracleDriver");
		bds.setUrl("jdbc:oracle:thin:@localhost:1521:xe");
		bds.setUsername("system");
		bds.setPassword("admin");
		bds.setMaxActive(15);
		bds.setMaxWait(2000);
		return bds;
	}
	
		@Bean
	public RestTemplate createRestTemplates() {
		return new RestTemplate();
	}

	@Bean
	public Gson createGson() {
		return new Gson();
	}

}
