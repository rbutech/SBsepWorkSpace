package com.rbu.ems.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rbu.ems.dao.EmpDao;

@Service
public class EmpService {
	@Autowired
	EmpDao dao;
	
	public EmpService() {
	System.out.println("EmpService object created");
	}
	
	

	public String create(int id, String name, String email, String address) {
		System.out.println("vai datasource");
		String msg = dao.save(id, name, email, address);
		return msg;
	}
	public String createjdbc(int id, String name, String email, String address) {
		System.out.println("vai jdbc");
		String msg = dao.savejdbc(id, name, email, address);
		return msg;
	}

}
