package com.rbu.ems.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.rbu.ems.service.EmpService;

@Controller
public class EmpController {
	@Autowired
	EmpService empService;

	public EmpController() {
		System.out.println("EmpController object created");
	}
	//1000 students are calling this method 10000 all success
	public String post(int id, String name, String email, String address) {
		String msg = empService.create(id, name, email, address);
		return msg;
	}
	//1000 students are calling this method 10000 only 300 success
	public String postJdbc(int id, String name, String email, String address) {
		String msg = empService.createjdbc(id, name, email, address);
		return msg;
	}

}
