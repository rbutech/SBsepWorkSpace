package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.rbu.ems.web.EmpController;

public class IOCTest {
	public static void main(String[] args) {

		ApplicationContext ap = new ClassPathXmlApplicationContext("resources/spring.xml");

		EmpController emp = ap.getBean(EmpController.class);
		for (int i = 8; i < 10008; i++) {
			System.out.println("insert count:" + i);
			String msg = emp.post(i, "Nitesh", "Nitesh@gmail.com", "HYD");
			System.out.println(msg);
		}

	}
}
