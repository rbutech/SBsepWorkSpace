package test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.rbu.ems.web.EmpController;

public class IOCTestJdbc {
	public static void main(String[] args) {

		ApplicationContext ap = new ClassPathXmlApplicationContext("resources/spring.xml");

		EmpController emp = ap.getBean(EmpController.class);
		for (int i = 10008; i < 20008; i++) {
			System.out.println("insert count:" + i);
			String msg = emp.postJdbc(i, "Nitesh", "Nitesh@gmail.com", "HYD");
			System.out.println(msg);
		}

	}
}
